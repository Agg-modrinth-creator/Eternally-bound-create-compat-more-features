package dev.ryanhcode.sable.companion;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface LoadPriority {
  int value() default 1000;
}


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\SableCompanion$LoadPriority.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */