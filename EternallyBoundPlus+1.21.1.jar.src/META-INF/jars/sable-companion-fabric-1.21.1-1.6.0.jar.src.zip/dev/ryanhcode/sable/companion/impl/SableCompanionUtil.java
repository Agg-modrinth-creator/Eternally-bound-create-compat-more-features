/*    */ package dev.ryanhcode.sable.companion.impl;
/*    */ 
/*    */ import com.mojang.serialization.Codec;
/*    */ import com.mojang.serialization.DataResult;
/*    */ import java.util.List;
/*    */ import java.util.function.Supplier;
/*    */ import org.jetbrains.annotations.ApiStatus.Internal;
/*    */ import org.joml.Quaterniond;
/*    */ import org.joml.Vector3d;
/*    */ 
/*    */ @Internal
/*    */ public final class SableCompanionUtil {
/*    */   public static final Codec<Vector3d> VECTOR_3D_CODEC;
/*    */   
/*    */   static {
/* 16 */     VECTOR_3D_CODEC = Codec.DOUBLE.listOf().comapFlatMap(l -> fixedSize(l, 3).map(()), vec -> List.of(Double.valueOf(vec.x), Double.valueOf(vec.y), Double.valueOf(vec.z)));
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 21 */     QUATERNIOND_CODEC = Codec.DOUBLE.listOf().comapFlatMap(l -> fixedSize(l, 4).map(()), quat -> List.of(Double.valueOf(quat.x), Double.valueOf(quat.y), Double.valueOf(quat.z), Double.valueOf(quat.w)));
/*    */   }
/*    */   public static final Codec<Quaterniond> QUATERNIOND_CODEC;
/*    */   
/*    */   public static <T> DataResult<List<T>> fixedSize(List<T> list, int size) {
/* 26 */     if (list.size() != size) {
/* 27 */       Supplier<String> supplier = () -> "Input is not a list of " + size + " elements";
/* 28 */       return (list.size() >= size) ? DataResult.error(supplier, list.subList(0, size)) : DataResult.error(supplier);
/*    */     } 
/* 30 */     return DataResult.success(list);
/*    */   }
/*    */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\impl\SableCompanionUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */