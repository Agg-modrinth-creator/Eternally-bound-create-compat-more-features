/*     */ package dev.ryanhcode.sable.companion.math;
/*     */ 
/*     */ import com.mojang.datafixers.kinds.App;
/*     */ import com.mojang.datafixers.kinds.Applicative;
/*     */ import com.mojang.datafixers.util.Function4;
/*     */ import com.mojang.serialization.Codec;
/*     */ import com.mojang.serialization.codecs.RecordCodecBuilder;
/*     */ import dev.ryanhcode.sable.companion.impl.SableCompanionUtil;
/*     */ import java.text.NumberFormat;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.joml.Quaterniond;
/*     */ import org.joml.Quaterniondc;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector3dc;
/*     */ 
/*     */ public final class Pose3d implements Pose3dc {
/*     */   public static Codec<Pose3d> CODEC;
/*     */   
/*     */   static {
/*  20 */     CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SableCompanionUtil.VECTOR_3D_CODEC.fieldOf("position").forGetter(Pose3d::position), (App)SableCompanionUtil.QUATERNIOND_CODEC.fieldOf("orientation").forGetter(Pose3d::orientation), (App)SableCompanionUtil.VECTOR_3D_CODEC.fieldOf("rotation_point").forGetter(Pose3d::rotationPoint), (App)SableCompanionUtil.VECTOR_3D_CODEC.fieldOf("scale").forGetter(Pose3d::scale)).apply((Applicative)instance, Pose3d::new));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Vector3d position;
/*     */ 
/*     */   
/*     */   private final Quaterniond orientation;
/*     */ 
/*     */   
/*     */   private final Vector3d rotationPoint;
/*     */ 
/*     */   
/*     */   private final Vector3d scale;
/*     */ 
/*     */ 
/*     */   
/*     */   public Pose3d(Vector3d position, Quaterniond orientation, Vector3d rotationPoint, Vector3d scale) {
/*  40 */     this.position = position;
/*  41 */     this.orientation = orientation;
/*  42 */     this.rotationPoint = rotationPoint;
/*  43 */     this.scale = scale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pose3d() {
/*  50 */     this.position = new Vector3d();
/*  51 */     this.orientation = new Quaterniond();
/*  52 */     this.rotationPoint = new Vector3d();
/*  53 */     this.scale = new Vector3d(1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pose3d(Pose3dc pose) {
/*  60 */     this.position = new Vector3d(pose.position());
/*  61 */     this.orientation = new Quaterniond(pose.orientation());
/*  62 */     this.rotationPoint = new Vector3d(pose.rotationPoint());
/*  63 */     this.scale = new Vector3d(pose.scale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public Pose3d set(Pose3dc pose) {
/*  74 */     this.position.set(pose.position());
/*  75 */     this.orientation.set(pose.orientation());
/*  76 */     this.rotationPoint.set(pose.rotationPoint());
/*  77 */     this.scale.set(pose.scale());
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->this", mutates = "this")
/*     */   public Pose3d lerp(Pose3dc pose, double frac) {
/*  90 */     return lerp(pose, frac, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d position() {
/*  98 */     return this.position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Quaterniond orientation() {
/* 106 */     return this.orientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d rotationPoint() {
/* 114 */     return this.rotationPoint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector3d scale() {
/* 122 */     return this.scale;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 127 */     NumberFormat numberFormat = NumberFormat.getInstance();
/*     */     
/* 129 */     return "Pose3d{position=%s, orientation=%s, rotationPoint=%s, scale=%s}"
/* 130 */       .formatted(new Object[] { this.position.toString(numberFormat), this.orientation
/* 131 */           .toString(numberFormat), this.rotationPoint
/* 132 */           .toString(numberFormat), this.scale
/* 133 */           .toString(numberFormat) });
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\math\Pose3d.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */