/*     */ package dev.ryanhcode.sable.companion.math;
/*     */ 
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_3341;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.joml.Vector3dc;
/*     */ import org.joml.Vector3i;
/*     */ import org.joml.Vector3ic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface BoundingBox3ic
/*     */ {
/*     */   @Contract(pure = true)
/*     */   default boolean intersects(BoundingBox3ic other) {
/*  24 */     return intersects(other.minX(), other.minY(), other.minZ(), other.maxX(), other.maxY(), other.maxZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean intersects(class_3341 other) {
/*  32 */     return intersects(other.method_35415(), other.method_35416(), other.method_35417(), other.method_35418(), other.method_35419(), other.method_35420());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean intersects(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
/*  40 */     return (maxX() >= minX && maxY() >= minY && maxZ() >= minZ && minX() <= maxX && minY() <= maxY && minZ() <= maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean contains(Vector3ic point) {
/*  48 */     return contains(point.x(), point.y(), point.z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean contains(int x, int y, int z) {
/*  56 */     return (x >= minX() && x <= maxX() && y >= minY() && y <= maxY() && z >= minZ() && z <= maxZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean contains(Vector3dc other) {
/*  64 */     return (other.x() >= minX() && other.x() <= (maxX() + 1) && other.y() >= minY() && other.y() <= (maxY() + 1) && other.z() >= minZ() && other.z() <= (maxZ() + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   int minX();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   int minY();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   int minZ();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   int maxX();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   int maxY();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   int maxZ();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default BoundingBox3i expandTo(Vector3ic point, BoundingBox3i dest) {
/* 111 */     return expandTo(point.x(), point.y(), point.z(), dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_->param4", mutates = "param4")
/*     */   default BoundingBox3i expandTo(int x, int y, int z, BoundingBox3i dest) {
/* 124 */     dest.set(this);
/* 125 */     dest.maxX = Math.max(dest.maxX, x);
/* 126 */     dest.maxY = Math.max(dest.maxY, y);
/* 127 */     dest.maxZ = Math.max(dest.maxZ, z);
/* 128 */     dest.minX = Math.min(dest.minX, x);
/* 129 */     dest.minY = Math.min(dest.minY, y);
/* 130 */     dest.minZ = Math.min(dest.minZ, z);
/* 131 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default BoundingBox3i expandTo(BoundingBox3ic other, BoundingBox3i dest) {
/* 142 */     dest.set(this);
/* 143 */     dest.maxX = Math.max(dest.maxX, other.maxX());
/* 144 */     dest.maxY = Math.max(dest.maxY, other.maxY());
/* 145 */     dest.maxZ = Math.max(dest.maxZ, other.maxZ());
/* 146 */     dest.minX = Math.min(dest.minX, other.minX());
/* 147 */     dest.minY = Math.min(dest.minY, other.minY());
/* 148 */     dest.minZ = Math.min(dest.minZ, other.minZ());
/* 149 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default BoundingBox3i move(Vector3ic vec, BoundingBox3i dest) {
/* 160 */     return move(vec.x(), vec.y(), vec.z(), dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_->param4", mutates = "param4")
/*     */   default BoundingBox3i move(int x, int y, int z, BoundingBox3i dest) {
/* 173 */     dest.set(this);
/* 174 */     dest.minX += x;
/* 175 */     dest.minY += y;
/* 176 */     dest.minZ += z;
/* 177 */     dest.maxX += x;
/* 178 */     dest.maxY += y;
/* 179 */     dest.maxZ += z;
/* 180 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default BoundingBox3i intersect(BoundingBox3ic box, BoundingBox3i dest) {
/* 192 */     dest.setUnchecked(
/* 193 */         Math.max(minX(), box.minX()), 
/* 194 */         Math.max(minY(), box.minY()), 
/* 195 */         Math.max(minZ(), box.minZ()), 
/* 196 */         Math.min(maxX(), box.maxX()), 
/* 197 */         Math.min(maxY(), box.maxY()), 
/* 198 */         Math.min(maxZ(), box.maxZ()));
/* 199 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default Vector3i center(Vector3i dest) {
/* 207 */     return dest.set((minX() + maxX()) / 2, (minY() + maxY()) / 2, (minZ() + maxZ()) / 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default Vector3i size(Vector3i dest) {
/* 215 */     return dest.set(maxX() - minX(), maxY() - minY(), maxZ() - minZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default int width() {
/* 223 */     return maxX() - minX() + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default int height() {
/* 231 */     return maxY() - minY() + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default int length() {
/* 239 */     return maxZ() - minZ() + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default int volume() {
/* 247 */     return (maxX() - minX() + 1) * (maxY() - minY() + 1) * (maxZ() - minZ() + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "->new", pure = true)
/*     */   default BoundingBox3i chunkBoundsFrom() {
/* 255 */     return chunkBoundsFrom(new BoundingBox3i());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default BoundingBox3i chunkBoundsFrom(BoundingBox3i dest) {
/* 263 */     return dest.set(
/* 264 */         minX() >> 4, 
/* 265 */         minY() >> 4, 
/* 266 */         minZ() >> 4, 
/* 267 */         maxX() >> 4, 
/* 268 */         maxY() >> 4, 
/* 269 */         maxZ() >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "->new", pure = true)
/*     */   default class_238 toAABB() {
/* 278 */     return new class_238(
/* 279 */         minX(), minY(), minZ(), (
/* 280 */         maxX() + 1), (maxY() + 1), (maxZ() + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "->new", pure = true)
/*     */   default class_3341 toMojang() {
/* 289 */     return new class_3341(
/* 290 */         minX(), minY(), minZ(), 
/* 291 */         maxX(), maxY(), maxZ());
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\math\BoundingBox3ic.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */