/*     */ package dev.ryanhcode.sable.companion;
/*     */ 
/*     */ import dev.ryanhcode.sable.companion.math.BoundingBox3dc;
/*     */ import dev.ryanhcode.sable.companion.math.JOMLConversion;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.util.Comparator;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.function.BiFunction;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2374;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2586;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4076;
/*     */ import org.jetbrains.annotations.ApiStatus.OverrideOnly;
/*     */ import org.jetbrains.annotations.ApiStatus.ScheduledForRemoval;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Quaterniondc;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector3dc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface SableCompanion
/*     */ {
/*     */   public static final SableCompanion INSTANCE;
/*     */   
/*     */   static {
/*  55 */     INSTANCE = (SableCompanion)ServiceLoader.<SableCompanion>load(SableCompanion.class).stream().max(Comparator.comparingInt(provider -> { Class<? extends SableCompanion> type = provider.type(); LoadPriority annotation = type.<LoadPriority>getAnnotation(LoadPriority.class); return (annotation != null) ? annotation.value() : 1000; })).map(ServiceLoader.Provider::get).orElseThrow(() -> new RuntimeException("Failed to find any sable companion implementation"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_1937 level, class_1923 chunkPos) {
/*  86 */     return getContaining(level, chunkPos.field_9181, chunkPos.field_9180);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_1937 level, class_4076 pos) {
/*  99 */     return getContaining(level, pos.method_10263(), pos.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_1937 level, class_2382 pos) {
/* 111 */     return getContaining(level, pos.method_10263() >> 4, pos.method_10260() >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_1937 level, class_2374 pos) {
/* 123 */     return getContaining(level, class_3532.method_15357(pos.method_10216()) >> 4, class_3532.method_15357(pos.method_10215()) >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_1937 level, Vector3dc pos) {
/* 135 */     return getContaining(level, class_3532.method_15357(pos.x()) >> 4, class_3532.method_15357(pos.z()) >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_1937 level, double blockX, double blockZ) {
/* 149 */     return getContaining(level, class_3532.method_15357(blockX) >> 4, class_3532.method_15357(blockZ) >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_1297 entity) {
/* 160 */     return getContaining(entity.method_37908(), entity.method_31476());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default SubLevelAccess getContaining(class_2586 blockEntity) {
/* 171 */     return getContaining(blockEntity.method_10997(), (class_2382)blockEntity.method_11016());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(int chunkX, int chunkZ) {
/* 184 */     return (ClientSubLevelAccess)getContaining(getClientLevel(), chunkX, chunkZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(class_1923 chunkPos) {
/* 196 */     return (ClientSubLevelAccess)getContaining(getClientLevel(), chunkPos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(class_2374 pos) {
/* 207 */     return (ClientSubLevelAccess)getContaining(getClientLevel(), pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(Vector3dc pos) {
/* 218 */     return (ClientSubLevelAccess)getContaining(getClientLevel(), pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(class_4076 pos) {
/* 230 */     return (ClientSubLevelAccess)getContaining(getClientLevel(), pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(class_2382 pos) {
/* 241 */     return (ClientSubLevelAccess)getContaining(getClientLevel(), pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(double blockX, double blockZ) {
/* 254 */     return (ClientSubLevelAccess)getContaining(getClientLevel(), blockX, blockZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(class_1297 entity) {
/* 266 */     return (ClientSubLevelAccess)getContaining(entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   default ClientSubLevelAccess getContainingClient(class_2586 blockEntity) {
/* 278 */     return (ClientSubLevelAccess)getContaining(blockEntity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default Vector3d projectOutOfSubLevel(class_1937 level, Vector3d pos) {
/* 291 */     return projectOutOfSubLevel(level, (Vector3dc)pos, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->new", pure = true)
/*     */   default class_243 projectOutOfSubLevel(class_1937 level, class_2374 pos) {
/* 327 */     return projectOutOfSubLevel(level, new class_243(pos.method_10216(), pos.method_10214(), pos.method_10215()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   @Contract(pure = true)
/*     */   default <T, S extends SubLevelAccess> T runIncludingSubLevels(class_1937 level, class_2374 origin, boolean shouldCheckOrigin, @Nullable S subLevel, BiFunction<S, class_2338, T> converter) {
/* 365 */     return runIncludingSubLevels(level, new class_243(origin.method_10216(), origin.method_10214(), origin.method_10215()), shouldCheckOrigin, subLevel, converter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default <S extends SubLevelAccess> boolean findIncludingSubLevels(class_1937 level, class_2374 origin, boolean shouldCheckOrigin, @Nullable S subLevel, BiFunction<S, class_2338, Boolean> converter) {
/* 399 */     return findIncludingSubLevels(level, new class_243(origin.method_10216(), origin.method_10214(), origin.method_10215()), shouldCheckOrigin, subLevel, converter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default Vector3d getVelocity(class_1937 level, Vector3d pos) {
/* 557 */     return getVelocity(level, (Vector3dc)pos, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->new", pure = true)
/*     */   default class_243 getVelocity(class_1937 level, class_2374 pos) {
/* 583 */     return getVelocity(level, new class_243(pos.method_10216(), pos.method_10214(), pos.method_10215()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->param3", mutates = "param3")
/*     */   default Vector3d getVelocity(class_1937 level, SubLevelAccess subLevel, Vector3d pos) {
/* 609 */     return getVelocity(level, subLevel, (Vector3dc)pos, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->new", pure = true)
/*     */   default class_243 getVelocity(class_1937 level, SubLevelAccess subLevel, class_2374 pos) {
/* 637 */     return getVelocity(level, subLevel, new class_243(pos.method_10216(), pos.method_10214(), pos.method_10215()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default Vector3d getVelocityRelativeToAir(class_1937 level, Vector3d pos) {
/* 665 */     return getVelocityRelativeToAir(level, (Vector3dc)pos, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(pure = true)
/*     */   default class_243 getVelocityRelativeToAir(class_1937 level, class_2374 pos) {
/* 693 */     return getVelocity(level, new class_243(pos.method_10216(), pos.method_10214(), pos.method_10215()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isInPlotGrid(class_1937 level, class_1923 chunkPos) {
/* 716 */     return isInPlotGrid(level, chunkPos.field_9181, chunkPos.field_9180);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isInPlotGrid(class_1937 level, class_4076 pos) {
/* 729 */     return isInPlotGrid(level, pos.method_10263(), pos.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isInPlotGrid(class_1937 level, class_2382 pos) {
/* 741 */     return isInPlotGrid(level, pos.method_10263() >> 4, pos.method_10260() >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isInPlotGrid(class_1937 level, class_2374 pos) {
/* 753 */     return isInPlotGrid(level, class_3532.method_15357(pos.method_10216()) >> 4, class_3532.method_15357(pos.method_10215()) >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isInPlotGrid(class_1937 level, Vector3dc pos) {
/* 765 */     return isInPlotGrid(level, class_3532.method_15357(pos.x()) >> 4, class_3532.method_15357(pos.z()) >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isInPlotGrid(class_1297 entity) {
/* 776 */     return isInPlotGrid(entity.method_37908(), entity.method_31476());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean isInPlotGrid(class_2586 blockEntity) {
/* 787 */     return isInPlotGrid(blockEntity.method_10997(), (class_2382)blockEntity.method_11016());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default Vector3d getFeetPos(class_1297 entity, float distanceDown, @Nullable Quaterniondc orientation) {
/*     */     Vector3d feetPos;
/* 862 */     if (orientation == null) {
/* 863 */       feetPos = JOMLConversion.toJOML((class_2374)entity.method_19538()).sub(0.0D, distanceDown, 0.0D);
/*     */     } else {
/* 865 */       feetPos = JOMLConversion.toJOML((class_2374)entity.method_19538()).sub((Vector3dc)orientation.transform(new Vector3d(0.0D, (distanceDown + entity.method_5751()), 0.0D)));
/*     */     } 
/*     */     
/* 868 */     return feetPos;
/*     */   }
/*     */   
/*     */   @Contract(pure = true)
/*     */   Iterable<? extends SubLevelAccess> getAllIntersecting(class_1937 paramclass_1937, BoundingBox3dc paramBoundingBox3dc);
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   SubLevelAccess getContaining(class_1937 paramclass_1937, int paramInt1, int paramInt2);
/*     */   
/*     */   @Contract(value = "_,_,_->param3", mutates = "param3")
/*     */   Vector3d projectOutOfSubLevel(class_1937 paramclass_1937, Vector3dc paramVector3dc, Vector3d paramVector3d);
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(value = "_,_->new", pure = true)
/*     */   class_243 projectOutOfSubLevel(class_1937 paramclass_1937, class_243 paramclass_243);
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Nullable
/*     */   @Contract(pure = true)
/*     */   <T, S extends SubLevelAccess> T runIncludingSubLevels(class_1937 paramclass_1937, class_243 paramclass_243, boolean paramBoolean, @Nullable S paramS, BiFunction<S, class_2338, T> paramBiFunction);
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(pure = true)
/*     */   <S extends SubLevelAccess> boolean findIncludingSubLevels(class_1937 paramclass_1937, class_243 paramclass_243, boolean paramBoolean, @Nullable S paramS, BiFunction<S, class_2338, Boolean> paramBiFunction);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double distanceSquaredWithSubLevels(class_1937 paramclass_1937, Vector3dc paramVector3dc1, Vector3dc paramVector3dc2);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double distanceSquaredWithSubLevels(class_1937 paramclass_1937, class_2374 paramclass_23741, class_2374 paramclass_23742);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double distanceSquaredWithSubLevels(class_1937 paramclass_1937, Vector3dc paramVector3dc, double paramDouble1, double paramDouble2, double paramDouble3);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double distanceSquaredWithSubLevels(class_1937 paramclass_1937, class_2374 paramclass_2374, double paramDouble1, double paramDouble2, double paramDouble3);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double distanceSquaredWithSubLevels(class_1937 paramclass_1937, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double rectilinearDistanceWithSubLevels(class_1937 paramclass_1937, Vector3dc paramVector3dc1, Vector3dc paramVector3dc2);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double rectilinearDistanceWithSubLevels(class_1937 paramclass_1937, class_2374 paramclass_23741, class_2374 paramclass_23742);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double rectilinearDistanceWithSubLevels(class_1937 paramclass_1937, Vector3dc paramVector3dc, double paramDouble1, double paramDouble2, double paramDouble3);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double rectilinearDistanceWithSubLevels(class_1937 paramclass_1937, class_2374 paramclass_2374, double paramDouble1, double paramDouble2, double paramDouble3);
/*     */   
/*     */   @Contract(pure = true)
/*     */   double rectilinearDistanceWithSubLevels(class_1937 paramclass_1937, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*     */   
/*     */   @Contract(value = "_,_,_->param3", mutates = "param3")
/*     */   Vector3d getVelocity(class_1937 paramclass_1937, Vector3dc paramVector3dc, Vector3d paramVector3d);
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(value = "_,_->new", pure = true)
/*     */   class_243 getVelocity(class_1937 paramclass_1937, class_243 paramclass_243);
/*     */   
/*     */   @Contract(value = "_,_,_,_->param4", mutates = "param4")
/*     */   Vector3d getVelocity(class_1937 paramclass_1937, SubLevelAccess paramSubLevelAccess, Vector3dc paramVector3dc, Vector3d paramVector3d);
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(value = "_,_,_->new", pure = true)
/*     */   class_243 getVelocity(class_1937 paramclass_1937, SubLevelAccess paramSubLevelAccess, class_243 paramclass_243);
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(value = "_,_,_->param3", mutates = "param3")
/*     */   Vector3d getVelocityRelativeToAir(class_1937 paramclass_1937, Vector3dc paramVector3dc, Vector3d paramVector3d);
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   @Contract(pure = true)
/*     */   class_243 getVelocityRelativeToAir(class_1937 paramclass_1937, class_243 paramclass_243);
/*     */   
/*     */   @Contract(pure = true)
/*     */   boolean isInPlotGrid(class_1937 paramclass_1937, int paramInt1, int paramInt2);
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   SubLevelAccess getTrackingSubLevel(class_1297 paramclass_1297);
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   SubLevelAccess getLastTrackingSubLevel(class_1297 paramclass_1297);
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   SubLevelAccess getTrackingOrVehicleSubLevel(class_1297 paramclass_1297);
/*     */   
/*     */   @Contract(pure = true)
/*     */   @Nullable
/*     */   SubLevelAccess getVehicleSubLevel(class_1297 paramclass_1297);
/*     */   
/*     */   @Contract(pure = true)
/*     */   class_243 getEyePositionInterpolated(class_1297 paramclass_1297, float paramFloat);
/*     */   
/*     */   @Contract(pure = true)
/*     */   Vector3d getFeetPos(class_1297 paramclass_1297, float paramFloat);
/*     */   
/*     */   @OverrideOnly
/*     */   class_1937 getClientLevel();
/*     */   
/*     */   @Retention(RetentionPolicy.RUNTIME)
/*     */   public static @interface LoadPriority {
/*     */     int value() default 1000;
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\SableCompanion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */