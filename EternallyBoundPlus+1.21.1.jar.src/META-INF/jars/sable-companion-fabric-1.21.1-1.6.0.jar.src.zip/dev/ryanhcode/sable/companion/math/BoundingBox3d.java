/*     */ package dev.ryanhcode.sable.companion.math;
/*     */ 
/*     */ import com.mojang.serialization.Codec;
/*     */ import com.mojang.serialization.DataResult;
/*     */ import dev.ryanhcode.sable.companion.impl.SableCompanionUtil;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2374;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3341;
/*     */ import org.jetbrains.annotations.ApiStatus.ScheduledForRemoval;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.joml.Matrix4d;
/*     */ import org.joml.Matrix4dc;
/*     */ import org.joml.Vector3dc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BoundingBox3d
/*     */   implements BoundingBox3dc
/*     */ {
/*  26 */   public static final BoundingBox3d EMPTY = new BoundingBox3d(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
/*     */   static {
/*  28 */     CODEC = Codec.DOUBLE.listOf().comapFlatMap(list -> SableCompanionUtil.fixedSize(list, 6).map(()), bb -> List.of(Double.valueOf(bb.minX), Double.valueOf(bb.minY), Double.valueOf(bb.minZ), Double.valueOf(bb.maxX), Double.valueOf(bb.maxY), Double.valueOf(bb.maxZ)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Codec<BoundingBox3d> CODEC;
/*     */ 
/*     */   
/*     */   public double minX;
/*     */ 
/*     */   
/*     */   public double minY;
/*     */ 
/*     */   
/*     */   public double minZ;
/*     */ 
/*     */   
/*     */   public double maxX;
/*     */   
/*     */   public double maxY;
/*     */   
/*     */   public double maxZ;
/*     */ 
/*     */   
/*     */   public BoundingBox3d(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
/*  53 */     set(minX, minY, minZ, maxX, maxY, maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3d(BoundingBox3dc other) {
/*  60 */     set(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3d(class_238 other) {
/*  67 */     set(other.field_1323, other.field_1322, other.field_1321, other.field_1320, other.field_1325, other.field_1324);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3d(class_3341 other) {
/*  74 */     set(other.method_35415(), other.method_35416(), other.method_35417(), other.method_35418(), other.method_35419(), other.method_35420());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3d(class_2338 pos) {
/*  81 */     set(pos.method_10263(), pos.method_10264(), pos.method_10260(), (pos.method_10263() + 1), (pos.method_10264() + 1), (pos.method_10260() + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3d(BoundingBox3ic other) {
/*  88 */     set(other.minX(), other.minY(), other.minZ(), (other.maxX() + 1), (other.maxY() + 1), (other.maxZ() + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   @ScheduledForRemoval(inVersion = "2.0.0")
/*     */   public BoundingBox3d(class_243 from, class_243 to) {
/*  99 */     set(from.field_1352, from.field_1351, from.field_1350, to.field_1352, to.field_1351, to.field_1350);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3d(class_2374 from, class_2374 to) {
/* 108 */     set(from.method_10216(), from.method_10214(), from.method_10215(), to.method_10216(), to.method_10214(), to.method_10215());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3d() {
/* 115 */     set(0.0D, 0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d set(BoundingBox3dc other) {
/* 123 */     set(other.minX(), other.minY(), other.minZ(), other.maxX(), other.maxY(), other.maxZ());
/* 124 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d set(class_238 other) {
/* 132 */     set(other.field_1323, other.field_1322, other.field_1321, other.field_1320, other.field_1325, other.field_1324);
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_,_,_->this", mutates = "this")
/*     */   public BoundingBox3d set(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
/* 142 */     this.minX = Math.min(minX, maxX);
/* 143 */     this.minY = Math.min(minY, maxY);
/* 144 */     this.minZ = Math.min(minZ, maxZ);
/* 145 */     this.maxX = Math.max(minX, maxX);
/* 146 */     this.maxY = Math.max(minY, maxY);
/* 147 */     this.maxZ = Math.max(minZ, maxZ);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_,_,_->this", mutates = "this")
/*     */   public BoundingBox3d setUnchecked(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
/* 158 */     this.minX = minX;
/* 159 */     this.minY = minY;
/* 160 */     this.minZ = minZ;
/* 161 */     this.maxX = maxX;
/* 162 */     this.maxY = maxY;
/* 163 */     this.maxZ = maxZ;
/* 164 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d setUnchecked(BoundingBox3dc other) {
/* 174 */     this.minX = other.minX();
/* 175 */     this.minY = other.minY();
/* 176 */     this.minZ = other.minZ();
/* 177 */     this.maxX = other.maxX();
/* 178 */     this.maxY = other.maxY();
/* 179 */     this.maxZ = other.maxZ();
/* 180 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d expandTo(Vector3dc point) {
/* 191 */     return expandTo(point.x(), point.y(), point.z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->this", mutates = "this")
/*     */   public BoundingBox3d expandTo(double x, double y, double z) {
/* 204 */     return expandTo(x, y, z, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d expandTo(BoundingBox3dc other) {
/* 215 */     return expandTo(other, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d expand(double amount) {
/* 226 */     return expand(amount, amount, amount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->this", mutates = "this")
/*     */   public BoundingBox3d expand(double amountX, double amountY, double amountZ) {
/* 239 */     return expand(amountX, amountY, amountZ, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->this", mutates = "this")
/*     */   public BoundingBox3d move(double amountX, double amountY, double amountZ) {
/* 252 */     return move(amountX, amountY, amountZ, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d intersect(BoundingBox3dc box) {
/* 263 */     return intersect(box, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d transform(Pose3dc pose) {
/* 275 */     return transform(pose, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->this", mutates = "this")
/*     */   public BoundingBox3d transform(Pose3dc pose, Matrix4d bakedMatrix) {
/* 287 */     return transform(pose, bakedMatrix, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d transform(Matrix4dc mpose) {
/* 299 */     return transform(mpose, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d transformInverse(Pose3dc pose) {
/* 311 */     return transformInverse(pose, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->this", mutates = "this")
/*     */   public BoundingBox3d transformInverse(Pose3dc pose, Matrix4d bakedMatrix) {
/* 323 */     return transformInverse(pose, bakedMatrix, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3d transformInverse(Matrix4dc mpose) {
/* 335 */     return transformInverse(mpose, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double minX() {
/* 343 */     return this.minX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double minY() {
/* 351 */     return this.minY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double minZ() {
/* 359 */     return this.minZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double maxX() {
/* 367 */     return this.maxX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double maxY() {
/* 375 */     return this.maxY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double maxZ() {
/* 383 */     return this.maxZ;
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\math\BoundingBox3d.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */