/*     */ package dev.ryanhcode.sable.companion.impl;
/*     */ 
/*     */ import dev.ryanhcode.sable.companion.SableCompanion;
/*     */ import dev.ryanhcode.sable.companion.SableCompanion.LoadPriority;
/*     */ import dev.ryanhcode.sable.companion.SubLevelAccess;
/*     */ import dev.ryanhcode.sable.companion.math.BoundingBox3dc;
/*     */ import java.util.List;
/*     */ import java.util.function.BiFunction;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2374;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_310;
/*     */ import org.jetbrains.annotations.ApiStatus.Internal;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector3dc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @LoadPriority(500)
/*     */ @Internal
/*     */ public final class DefaultSableCompanion
/*     */   implements SableCompanion
/*     */ {
/*     */   public Iterable<SubLevelAccess> getAllIntersecting(class_1937 level, BoundingBox3dc bounds) {
/*  30 */     return List.of();
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SubLevelAccess getContaining(class_1937 level, int chunkX, int chunkZ) {
/*  35 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3d projectOutOfSubLevel(class_1937 level, Vector3dc pos, Vector3d dest) {
/*  40 */     return dest.set(pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 projectOutOfSubLevel(class_1937 level, class_243 pos) {
/*  45 */     return pos;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 projectOutOfSubLevel(class_1937 level, class_2374 pos) {
/*  50 */     class_243 vec3 = (class_243)pos; return (pos instanceof class_243) ? vec3 : new class_243(pos.method_10216(), pos.method_10214(), pos.method_10215());
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public <T, S extends SubLevelAccess> T runIncludingSubLevels(class_1937 level, class_243 origin, boolean shouldCheckOrigin, @Nullable S subLevel, BiFunction<S, class_2338, T> converter) {
/*  55 */     return shouldCheckOrigin ? converter.apply(subLevel, class_2338.method_49638((class_2374)origin)) : null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public <T, S extends SubLevelAccess> T runIncludingSubLevels(class_1937 level, class_2374 origin, boolean shouldCheckOrigin, @Nullable S subLevel, BiFunction<S, class_2338, T> converter) {
/*  60 */     return shouldCheckOrigin ? converter.apply(subLevel, class_2338.method_49638(origin)) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public <S extends SubLevelAccess> boolean findIncludingSubLevels(class_1937 level, class_243 origin, boolean shouldCheckOrigin, @Nullable S subLevel, BiFunction<S, class_2338, Boolean> converter) {
/*  65 */     return shouldCheckOrigin ? ((Boolean)converter.apply(subLevel, class_2338.method_49638((class_2374)origin))).booleanValue() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public <S extends SubLevelAccess> boolean findIncludingSubLevels(class_1937 level, class_2374 origin, boolean shouldCheckOrigin, @Nullable S subLevel, BiFunction<S, class_2338, Boolean> converter) {
/*  70 */     return shouldCheckOrigin ? ((Boolean)converter.apply(subLevel, class_2338.method_49638(origin))).booleanValue() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public double distanceSquaredWithSubLevels(class_1937 level, Vector3dc a, Vector3dc b) {
/*  75 */     return a.distanceSquared(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public double distanceSquaredWithSubLevels(class_1937 level, Vector3dc a, double bX, double bY, double bZ) {
/*  80 */     return a.distanceSquared(bX, bY, bZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public double distanceSquaredWithSubLevels(class_1937 level, class_2374 a, class_2374 b) {
/*  85 */     double d0 = a.method_10216() - b.method_10216();
/*  86 */     double d1 = b.method_10214() - b.method_10214();
/*  87 */     double d2 = b.method_10215() - b.method_10215();
/*  88 */     return d0 * d0 + d1 * d1 + d2 * d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public double distanceSquaredWithSubLevels(class_1937 level, class_2374 a, double bX, double bY, double bZ) {
/*  93 */     double d0 = a.method_10216() - bX;
/*  94 */     double d1 = a.method_10214() - bY;
/*  95 */     double d2 = a.method_10215() - bZ;
/*  96 */     return d0 * d0 + d1 * d1 + d2 * d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public double distanceSquaredWithSubLevels(class_1937 level, double aX, double aY, double aZ, double bX, double bY, double bZ) {
/* 101 */     double d0 = aX - bX;
/* 102 */     double d1 = aY - bY;
/* 103 */     double d2 = aZ - bZ;
/* 104 */     return d0 * d0 + d1 * d1 + d2 * d2;
/*     */   }
/*     */ 
/*     */   
/*     */   public double rectilinearDistanceWithSubLevels(class_1937 level, Vector3dc a, Vector3dc b) {
/* 109 */     return rectilinearDistanceWithSubLevels(level, a.x(), a.y(), a.z(), b.x(), b.y(), b.z());
/*     */   }
/*     */ 
/*     */   
/*     */   public double rectilinearDistanceWithSubLevels(class_1937 level, class_2374 a, class_2374 b) {
/* 114 */     return rectilinearDistanceWithSubLevels(level, a.method_10216(), a.method_10214(), a.method_10215(), b.method_10216(), b.method_10214(), b.method_10215());
/*     */   }
/*     */ 
/*     */   
/*     */   public double rectilinearDistanceWithSubLevels(class_1937 level, Vector3dc a, double bX, double bY, double bZ) {
/* 119 */     return rectilinearDistanceWithSubLevels(level, a.x(), a.y(), a.z(), bX, bY, bZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public double rectilinearDistanceWithSubLevels(class_1937 level, class_2374 a, double bX, double bY, double bZ) {
/* 124 */     return rectilinearDistanceWithSubLevels(level, a.method_10216(), a.method_10214(), a.method_10215(), bX, bY, bZ);
/*     */   }
/*     */ 
/*     */   
/*     */   public double rectilinearDistanceWithSubLevels(class_1937 level, double aX, double aY, double aZ, double bX, double bY, double bZ) {
/* 129 */     double d0 = Math.abs(aX - bX);
/* 130 */     double d1 = Math.abs(aY - bY);
/* 131 */     double d2 = Math.abs(aZ - bZ);
/* 132 */     return Math.max(d0, Math.max(d1, d2));
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3d getVelocity(class_1937 level, Vector3dc pos, Vector3d dest) {
/* 137 */     return dest.zero();
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 getVelocity(class_1937 level, class_243 pos) {
/* 142 */     return class_243.field_1353;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 getVelocity(class_1937 level, class_2374 pos) {
/* 147 */     return class_243.field_1353;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3d getVelocity(class_1937 level, SubLevelAccess subLevel, Vector3dc pos, Vector3d dest) {
/* 152 */     return dest.zero();
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 getVelocity(class_1937 level, SubLevelAccess subLevel, class_243 pos) {
/* 157 */     return class_243.field_1353;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 getVelocity(class_1937 level, SubLevelAccess subLevel, class_2374 pos) {
/* 162 */     return class_243.field_1353;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3d getVelocityRelativeToAir(class_1937 level, Vector3dc pos, Vector3d dest) {
/* 167 */     return dest.zero();
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 getVelocityRelativeToAir(class_1937 level, class_243 pos) {
/* 172 */     return class_243.field_1353;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 getVelocityRelativeToAir(class_1937 level, class_2374 pos) {
/* 177 */     return class_243.field_1353;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInPlotGrid(class_1937 level, int chunkX, int chunkZ) {
/* 182 */     return false;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SubLevelAccess getTrackingSubLevel(class_1297 entity) {
/* 187 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SubLevelAccess getLastTrackingSubLevel(class_1297 entity) {
/* 192 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SubLevelAccess getTrackingOrVehicleSubLevel(class_1297 entity) {
/* 197 */     return null;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SubLevelAccess getVehicleSubLevel(class_1297 entity) {
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_243 getEyePositionInterpolated(class_1297 entity, float partialTicks) {
/* 207 */     return entity.method_5836(partialTicks);
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public Vector3d getFeetPos(class_1297 entity, float distanceDown) {
/* 212 */     return getFeetPos(entity, distanceDown, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public class_1937 getClientLevel() {
/* 217 */     return DistHelper.getClientLevel();
/*     */   }
/*     */   
/*     */   private static final class DistHelper {
/*     */     public static class_1937 getClientLevel() {
/* 222 */       return (class_1937)(class_310.method_1551()).field_1687;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\impl\DefaultSableCompanion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */