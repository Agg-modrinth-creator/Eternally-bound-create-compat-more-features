/*     */ package dev.ryanhcode.sable.companion.math;
/*     */ 
/*     */ import com.mojang.serialization.Codec;
/*     */ import com.mojang.serialization.DataResult;
/*     */ import dev.ryanhcode.sable.companion.impl.SableCompanionUtil;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_3341;
/*     */ import net.minecraft.class_3532;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ import org.joml.Vector3ic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BoundingBox3i
/*     */   implements BoundingBox3ic
/*     */ {
/*  23 */   public static final BoundingBox3ic EMPTY = (new BoundingBox3i()).setUnchecked(2147483647, 2147483647, 2147483647, -2147483648, -2147483648, -2147483648);
/*     */   static {
/*  25 */     CODEC = Codec.INT.listOf().comapFlatMap(list -> SableCompanionUtil.fixedSize(list, 6).map(()), bb -> List.of(Integer.valueOf(bb.minX), Integer.valueOf(bb.minY), Integer.valueOf(bb.minZ), Integer.valueOf(bb.maxX), Integer.valueOf(bb.maxY), Integer.valueOf(bb.maxZ)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Codec<BoundingBox3i> CODEC;
/*     */ 
/*     */   
/*     */   public int minX;
/*     */ 
/*     */   
/*     */   public int minY;
/*     */ 
/*     */   
/*     */   public int minZ;
/*     */ 
/*     */   
/*     */   public int maxX;
/*     */   
/*     */   public int maxY;
/*     */   
/*     */   public int maxZ;
/*     */ 
/*     */   
/*     */   public BoundingBox3i(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
/*  50 */     set(minX, minY, minZ, maxX, maxY, maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3i(class_2338 min, class_2338 max) {
/*  57 */     set(min.method_10263(), min.method_10264(), min.method_10260(), max.method_10263(), max.method_10264(), max.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3i(BoundingBox3ic other) {
/*  64 */     set(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3i(class_3341 other) {
/*  71 */     set(other.method_35415(), other.method_35416(), other.method_35417(), other.method_35418(), other.method_35419(), other.method_35420());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3i() {
/*  78 */     this(0, 0, 0, 0, 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundingBox3i(BoundingBox3d other) {
/*  85 */     set(class_3532.method_15357(other.minX), class_3532.method_15357(other.minY), class_3532.method_15357(other.minZ), class_3532.method_15357(other.maxX), class_3532.method_15357(other.maxY), class_3532.method_15357(other.maxZ));
/*     */   }
/*     */   @Nullable
/*     */   public static BoundingBox3i from(Iterable<class_2338> blocks) {
/*  89 */     Iterator<class_2338> iterator = blocks.iterator();
/*  90 */     if (!iterator.hasNext()) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     class_2338 pos = iterator.next();
/*  95 */     int minX = pos.method_10263();
/*  96 */     int minY = pos.method_10264();
/*  97 */     int minZ = pos.method_10260();
/*  98 */     int maxX = minX;
/*  99 */     int maxY = minY;
/* 100 */     int maxZ = minZ;
/*     */     
/* 102 */     while (iterator.hasNext()) {
/* 103 */       pos = iterator.next();
/* 104 */       minX = Math.min(minX, pos.method_10263());
/* 105 */       minY = Math.min(minY, pos.method_10264());
/* 106 */       minZ = Math.min(minZ, pos.method_10260());
/* 107 */       maxX = Math.max(maxX, pos.method_10263());
/* 108 */       maxY = Math.max(maxY, pos.method_10264());
/* 109 */       maxZ = Math.max(maxZ, pos.method_10260());
/*     */     } 
/*     */     
/* 112 */     return new BoundingBox3i(minX, minY, minZ, maxX, maxY, maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3i set(BoundingBox3d other) {
/* 120 */     set(class_3532.method_15357(other.minX), class_3532.method_15357(other.minY), class_3532.method_15357(other.minZ), class_3532.method_15357(other.maxX), class_3532.method_15357(other.maxY), class_3532.method_15357(other.maxZ));
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3i set(BoundingBox3ic other) {
/* 129 */     set(other.minX(), other.minY(), other.minZ(), other.maxX(), other.maxY(), other.maxZ());
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_,_,_->this", mutates = "this")
/*     */   public BoundingBox3i set(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
/* 138 */     this.minX = Math.min(minX, maxX);
/* 139 */     this.minY = Math.min(minY, maxY);
/* 140 */     this.minZ = Math.min(minZ, maxZ);
/* 141 */     this.maxX = Math.max(minX, maxX);
/* 142 */     this.maxY = Math.max(minY, maxY);
/* 143 */     this.maxZ = Math.max(minZ, maxZ);
/* 144 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_,_,_->this", mutates = "this")
/*     */   public BoundingBox3i setUnchecked(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
/* 155 */     this.minX = minX;
/* 156 */     this.minY = minY;
/* 157 */     this.minZ = minZ;
/* 158 */     this.maxX = maxX;
/* 159 */     this.maxY = maxY;
/* 160 */     this.maxZ = maxZ;
/* 161 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3i setUnchecked(BoundingBox3ic other) {
/* 171 */     this.minX = other.minX();
/* 172 */     this.minY = other.minY();
/* 173 */     this.minZ = other.minZ();
/* 174 */     this.maxX = other.maxX();
/* 175 */     this.maxY = other.maxY();
/* 176 */     this.maxZ = other.maxZ();
/* 177 */     return this;
/*     */   }
/*     */   
/*     */   @Contract(value = "_,_,_->this", mutates = "this")
/*     */   public BoundingBox3i expand(int xExpansion, int yExpansion, int zExpansion) {
/* 182 */     this.minX -= xExpansion;
/* 183 */     this.minY -= yExpansion;
/* 184 */     this.minZ -= zExpansion;
/* 185 */     this.maxX += xExpansion;
/* 186 */     this.maxY += yExpansion;
/* 187 */     this.maxZ += zExpansion;
/* 188 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3i expandTo(Vector3ic point) {
/* 199 */     return expandTo(point, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->this", mutates = "this")
/*     */   public BoundingBox3i expandTo(int x, int y, int z) {
/* 212 */     return expandTo(x, y, z, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3i expandTo(BoundingBox3ic other) {
/* 223 */     return expandTo(other, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3i move(Vector3ic vec) {
/* 234 */     return move(vec.x(), vec.y(), vec.z(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->this", mutates = "this")
/*     */   public BoundingBox3i move(int x, int y, int z) {
/* 247 */     return move(x, y, z, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->this", mutates = "this")
/*     */   public BoundingBox3i intersect(BoundingBox3ic box) {
/* 258 */     return set(
/* 259 */         Math.max(minX(), box.minX()), 
/* 260 */         Math.max(minY(), box.minY()), 
/* 261 */         Math.max(minZ(), box.minZ()), 
/* 262 */         Math.min(maxX(), box.maxX()), 
/* 263 */         Math.min(maxY(), box.maxY()), 
/* 264 */         Math.min(maxZ(), box.maxZ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int minX() {
/* 272 */     return this.minX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int minY() {
/* 280 */     return this.minY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int minZ() {
/* 288 */     return this.minZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxX() {
/* 296 */     return this.maxX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxY() {
/* 304 */     return this.maxY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxZ() {
/* 312 */     return this.maxZ;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*     */     BoundingBox3ic other;
/* 317 */     if (this == obj) {
/* 318 */       return true;
/*     */     }
/* 320 */     if (obj instanceof BoundingBox3ic) { other = (BoundingBox3ic)obj; }
/* 321 */     else { return false; }
/*     */ 
/*     */     
/* 324 */     return (minX() == other.minX() && minY() == other.minY() && minZ() == other.minZ() && maxX() == other.maxX() && maxY() == other.maxY() && maxZ() == other.maxZ());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 329 */     int result = this.minX;
/* 330 */     result = 31 * result + this.minY;
/* 331 */     result = 31 * result + this.minZ;
/* 332 */     result = 31 * result + this.maxX;
/* 333 */     result = 31 * result + this.maxY;
/* 334 */     result = 31 * result + this.maxZ;
/* 335 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 340 */     return "BoundingBox3i{minX=" + this.minX + ", minY=" + this.minY + ", minZ=" + this.minZ + ", maxX=" + this.maxX + ", maxY=" + this.maxY + ", maxZ=" + this.maxZ + "}";
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\math\BoundingBox3i.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */