/*     */ package dev.ryanhcode.sable.companion.math;
/*     */ 
/*     */ import net.minecraft.class_2374;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.joml.Matrix4d;
/*     */ import org.joml.Quaterniond;
/*     */ import org.joml.Quaterniondc;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector3dc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Pose3dc
/*     */ {
/*     */   @Contract(pure = true)
/*     */   Vector3dc position();
/*     */   
/*     */   @Contract(pure = true)
/*     */   Quaterniondc orientation();
/*     */   
/*     */   @Contract(pure = true)
/*     */   Vector3dc rotationPoint();
/*     */   
/*     */   @Contract(pure = true)
/*     */   Vector3dc scale();
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default Vector3d transformPosition(Vector3dc local, Vector3d dest) {
/*  48 */     return orientation().transform(local.sub(rotationPoint(), dest).mul(scale())).add(position());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   default class_243 transformPosition(class_243 local) {
/*  59 */     return JOMLConversion.toMojang((Vector3dc)transformPosition(JOMLConversion.toJOML((class_2374)local)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   default class_243 transformPositionInverse(class_243 global) {
/*  70 */     return JOMLConversion.toMojang((Vector3dc)transformPositionInverse(JOMLConversion.toJOML((class_2374)global)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default Vector3d transformPositionInverse(Vector3dc global, Vector3d dest) {
/*  82 */     Vector3dc s = scale();
/*  83 */     return orientation().transformInverse(global.sub(position(), dest))
/*  84 */       .mul(1.0D / s
/*  85 */         .x(), 1.0D / s
/*  86 */         .y(), 1.0D / s
/*  87 */         .z()).add(rotationPoint());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default Vector3d transformNormal(Vector3dc local, Vector3d dest) {
/* 100 */     return orientation().transform(local.mul(scale(), dest));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   default Vector3d transformNormalInverse(Vector3dc global, Vector3d dest) {
/* 113 */     Vector3dc s = scale();
/* 114 */     return orientation().transformInverse(global, dest)
/* 115 */       .mul(1.0D / s
/* 116 */         .x(), 1.0D / s
/* 117 */         .y(), 1.0D / s
/* 118 */         .z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default Vector3d transformPosition(Vector3d local) {
/* 129 */     return transformPosition((Vector3dc)local, local);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default Vector3d transformPositionInverse(Vector3d global) {
/* 140 */     return transformPositionInverse((Vector3dc)global, global);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default Vector3d transformNormal(Vector3d local) {
/* 152 */     return transformNormal((Vector3dc)local, local);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default Vector3d transformNormalInverse(Vector3d global) {
/* 164 */     return transformNormalInverse((Vector3dc)global, global);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   default class_243 transformNormal(class_243 local) {
/* 176 */     return JOMLConversion.toMojang((Vector3dc)transformNormal(JOMLConversion.toJOML((class_2374)local)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   default class_243 transformNormalInverse(class_243 global) {
/* 188 */     return JOMLConversion.toMojang((Vector3dc)transformNormalInverse(JOMLConversion.toJOML((class_2374)global)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->param3", mutates = "param3")
/*     */   default Pose3d lerp(Pose3dc pose, double frac, Pose3d dest) {
/* 201 */     position().lerp(pose.position(), frac, dest.position());
/* 202 */     orientation().nlerp(pose.orientation(), frac, dest.orientation());
/* 203 */     rotationPoint().lerp(pose.rotationPoint(), frac, dest.rotationPoint());
/* 204 */     scale().lerp(pose.scale(), frac, dest.scale());
/* 205 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default Matrix4d bakeIntoMatrix(Matrix4d dest) {
/* 216 */     Vector3dc rotationPoint = rotationPoint();
/* 217 */     return dest.identity()
/* 218 */       .translate(position())
/* 219 */       .rotate(orientation())
/* 220 */       .scale(scale())
/* 221 */       .translate(-rotationPoint.x(), -rotationPoint.y(), -rotationPoint.z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default boolean withinTolerance(Pose3d pose3d, double distanceTolerance, double angularTolerance) {
/* 232 */     return (position().distanceSquared((Vector3dc)pose3d.position()) <= distanceTolerance * distanceTolerance && 
/* 233 */       rotationPoint().distanceSquared((Vector3dc)pose3d.rotationPoint()) <= distanceTolerance * distanceTolerance && 
/* 234 */       orientation().div((Quaterniondc)pose3d.orientation(), new Quaterniond()).angle() <= angularTolerance);
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\math\Pose3dc.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */