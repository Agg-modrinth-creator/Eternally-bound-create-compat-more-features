/*     */ package dev.ryanhcode.sable.companion.math;
/*     */ 
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_3532;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.joml.Matrix4d;
/*     */ import org.joml.Matrix4dc;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector3dc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface BoundingBox3dc
/*     */ {
/*     */   default boolean intersects(BoundingBox3dc other) {
/*  23 */     return intersects(other.minX(), other.minY(), other.minZ(), other.maxX(), other.maxY(), other.maxZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean intersects(class_238 other) {
/*  30 */     return intersects(other.field_1323, other.field_1322, other.field_1321, other.field_1320, other.field_1325, other.field_1324);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean intersects(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
/*  37 */     return (maxX() >= minX && maxY() >= minY && maxZ() >= minZ && minX() <= maxX && minY() <= maxY && minZ() <= maxZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean contains(Vector3dc point) {
/*  44 */     return contains(point.x(), point.y(), point.z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean contains(double x, double y, double z) {
/*  51 */     return (x >= minX() && x <= maxX() && y >= minY() && y <= maxY() && z >= minZ() && z <= maxZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double minX();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double minY();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double minZ();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double maxX();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double maxY();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double maxZ();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d expandTo(Vector3dc point, BoundingBox3d dest) {
/*  91 */     return expandTo(point.x(), point.y(), point.z(), dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d expandTo(double x, double y, double z, BoundingBox3d dest) {
/* 103 */     dest.setUnchecked(this);
/* 104 */     dest.maxX = Math.max(dest.maxX, x);
/* 105 */     dest.maxY = Math.max(dest.maxY, y);
/* 106 */     dest.maxZ = Math.max(dest.maxZ, z);
/* 107 */     dest.minX = Math.min(dest.minX, x);
/* 108 */     dest.minY = Math.min(dest.minY, y);
/* 109 */     dest.minZ = Math.min(dest.minZ, z);
/* 110 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d expandTo(BoundingBox3dc other, BoundingBox3d dest) {
/* 120 */     dest.setUnchecked(this);
/* 121 */     dest.maxX = Math.max(dest.maxX, other.maxX());
/* 122 */     dest.maxY = Math.max(dest.maxY, other.maxY());
/* 123 */     dest.maxZ = Math.max(dest.maxZ, other.maxZ());
/* 124 */     dest.minX = Math.min(dest.minX, other.minX());
/* 125 */     dest.minY = Math.min(dest.minY, other.minY());
/* 126 */     dest.minZ = Math.min(dest.minZ, other.minZ());
/* 127 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d expand(double amount, BoundingBox3d dest) {
/* 138 */     return dest.setUnchecked(
/* 139 */         minX() - amount, 
/* 140 */         minY() - amount, 
/* 141 */         minZ() - amount, 
/* 142 */         maxX() + amount, 
/* 143 */         maxY() + amount, 
/* 144 */         maxZ() + amount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d expand(double amountX, double amountY, double amountZ, BoundingBox3d dest) {
/* 157 */     return dest.setUnchecked(
/* 158 */         minX() - amountX, 
/* 159 */         minY() - amountY, 
/* 160 */         minZ() - amountZ, 
/* 161 */         maxX() + amountX, 
/* 162 */         maxY() + amountY, 
/* 163 */         maxZ() + amountZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d move(double amountX, double amountY, double amountZ, BoundingBox3d dest) {
/* 176 */     return dest.setUnchecked(
/* 177 */         minX() + amountX, 
/* 178 */         minY() + amountY, 
/* 179 */         minZ() + amountZ, 
/* 180 */         maxX() + amountX, 
/* 181 */         maxY() + amountY, 
/* 182 */         maxZ() + amountZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d intersect(BoundingBox3dc box, BoundingBox3d dest) {
/* 193 */     return dest.setUnchecked(
/* 194 */         Math.max(minX(), box.minX()), 
/* 195 */         Math.max(minY(), box.minY()), 
/* 196 */         Math.max(minZ(), box.minZ()), 
/* 197 */         Math.min(maxX(), box.maxX()), 
/* 198 */         Math.min(maxY(), box.maxY()), 
/* 199 */         Math.min(maxZ(), box.maxZ()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d transform(Pose3dc pose, BoundingBox3d dest) {
/* 211 */     return transform((Matrix4dc)pose.bakeIntoMatrix(new Matrix4d()), dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d transform(Pose3dc pose, Matrix4d bakedMatrix, BoundingBox3d dest) {
/* 223 */     return transform((Matrix4dc)pose.bakeIntoMatrix(bakedMatrix), dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d transform(Matrix4dc mpose, BoundingBox3d dest) {
/* 235 */     double minX = minX(), minY = minY(), minZ = minZ();
/* 236 */     double maxX = maxX(), maxY = maxY(), maxZ = maxZ();
/*     */     
/* 238 */     dest.setUnchecked(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
/*     */     
/* 240 */     Vector3d corner = new Vector3d();
/*     */     
/* 242 */     for (int i = 0; i <= 7; i++) {
/* 243 */       corner.set(
/* 244 */           ((i & 0x1) == 0) ? minX : maxX, 
/* 245 */           ((i & 0x2) == 0) ? minY : maxY, 
/* 246 */           ((i & 0x4) == 0) ? minZ : maxZ);
/*     */       
/* 248 */       dest.expandTo((Vector3dc)mpose.transformPosition(corner), dest);
/*     */     } 
/*     */     
/* 251 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d transformInverse(Pose3dc pose, BoundingBox3d dest) {
/* 263 */     return transformInverse((Matrix4dc)pose.bakeIntoMatrix(new Matrix4d()).invertAffine(), dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d transformInverse(Pose3dc pose, Matrix4d bakedMatrix, BoundingBox3d dest) {
/* 275 */     return transformInverse((Matrix4dc)pose.bakeIntoMatrix(bakedMatrix).invertAffine(), dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default BoundingBox3d transformInverse(Matrix4dc mpose, BoundingBox3d dest) {
/* 287 */     double minX = minX(), minY = minY(), minZ = minZ();
/* 288 */     double maxX = maxX(), maxY = maxY(), maxZ = maxZ();
/*     */     
/* 290 */     dest.setUnchecked(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY);
/*     */     
/* 292 */     Vector3d corner = new Vector3d();
/*     */     
/* 294 */     for (int i = 0; i <= 7; i++) {
/* 295 */       corner.set(
/* 296 */           ((i & 0x1) == 0) ? minX : maxX, 
/* 297 */           ((i & 0x2) == 0) ? minY : maxY, 
/* 298 */           ((i & 0x4) == 0) ? minZ : maxZ);
/*     */       
/* 300 */       dest.expandTo((Vector3dc)mpose.transformPosition(corner), dest);
/*     */     } 
/*     */     
/* 303 */     return dest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Vector3d center() {
/* 310 */     return center(new Vector3d());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Vector3d center(Vector3d dest) {
/* 317 */     return dest.set((minX() + maxX()) / 2.0D, (minY() + maxY()) / 2.0D, (minZ() + maxZ()) / 2.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Vector3d size() {
/* 324 */     return size(new Vector3d());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Vector3d size(Vector3d dest) {
/* 331 */     return dest.set(maxX() - minX(), maxY() - minY(), maxZ() - minZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "->new", pure = true)
/*     */   default BoundingBox3i chunkBoundsFrom() {
/* 339 */     return chunkBoundsFrom(new BoundingBox3i());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->param1", mutates = "param1")
/*     */   default BoundingBox3i chunkBoundsFrom(BoundingBox3i dest) {
/* 347 */     return dest.set(
/* 348 */         class_3532.method_15357(minX()) >> 4, 
/* 349 */         class_3532.method_15357(minY()) >> 4, 
/* 350 */         class_3532.method_15357(minZ()) >> 4, 
/* 351 */         class_3532.method_15357(maxX()) >> 4, 
/* 352 */         class_3532.method_15357(maxY()) >> 4, 
/* 353 */         class_3532.method_15357(maxZ()) >> 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default double width() {
/* 363 */     return maxX() - minX() + 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default double height() {
/* 372 */     return maxY() - minY() + 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default double length() {
/* 381 */     return maxZ() - minZ() + 1.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(pure = true)
/*     */   default double volume() {
/* 389 */     return (maxX() - minX()) * (maxY() - minY()) * (maxZ() - minZ());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "->new", pure = true)
/*     */   default class_238 toMojang() {
/* 397 */     return new class_238(minX(), minY(), minZ(), maxX(), maxY(), maxZ());
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\math\BoundingBox3dc.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */