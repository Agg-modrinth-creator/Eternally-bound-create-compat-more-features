package dev.ryanhcode.sable.companion;

import dev.ryanhcode.sable.companion.math.Pose3dc;
import org.jetbrains.annotations.Contract;

public interface ClientSubLevelAccess extends SubLevelAccess {
  @Contract(pure = true)
  Pose3dc renderPose();
  
  @Contract(pure = true)
  Pose3dc renderPose(float paramFloat);
}


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\ClientSubLevelAccess.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */