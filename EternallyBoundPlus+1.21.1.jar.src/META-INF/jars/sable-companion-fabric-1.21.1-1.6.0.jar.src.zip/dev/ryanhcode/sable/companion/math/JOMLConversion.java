/*     */ package dev.ryanhcode.sable.companion.math;
/*     */ import net.minecraft.class_2374;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_241;
/*     */ import net.minecraft.class_243;
/*     */ import org.jetbrains.annotations.Contract;
/*     */ import org.joml.Quaterniondc;
/*     */ import org.joml.Vector2f;
/*     */ import org.joml.Vector2fc;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector3dc;
/*     */ import org.joml.Vector3i;
/*     */ import org.joml.Vector3ic;
/*     */ 
/*     */ public final class JOMLConversion {
/*  17 */   public static final Vector3dc ZERO = (Vector3dc)new Vector3d();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  22 */   public static final Vector3dc ONE = (Vector3dc)new Vector3d(1.0D, 1.0D, 1.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  27 */   public static final Vector3dc HALF = (Vector3dc)new Vector3d(0.5D, 0.5D, 0.5D);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   public static final Quaterniondc QUAT_IDENTITY = (Quaterniondc)new Quaterniond();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   public static Vector3d toJOML(class_2374 vec3, Vector3d dest) {
/*  43 */     return dest.set(vec3.method_10216(), vec3.method_10214(), vec3.method_10215());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static Vector3d toJOML(class_2374 vec3) {
/*  54 */     return new Vector3d(vec3.method_10216(), vec3.method_10214(), vec3.method_10215());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   public static Vector2f toJOML(class_241 vec2, Vector2f dest) {
/*  66 */     return dest.set(vec2.field_1343, vec2.field_1342);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static Vector2f toJOML(class_241 vec2) {
/*  77 */     return new Vector2f(vec2.field_1343, vec2.field_1342);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   public static Vector3i toJOML(class_2382 vec3, Vector3i dest) {
/*  89 */     return dest.set(vec3.method_10263(), vec3.method_10264(), vec3.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static Vector3i toJOML(class_2382 vec3) {
/* 100 */     return new Vector3i(vec3.method_10263(), vec3.method_10264(), vec3.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   public static Vector3d atLowerCornerOf(class_2382 toCopy, Vector3d dest) {
/* 112 */     return dest.set(toCopy.method_10263(), toCopy.method_10264(), toCopy.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static Vector3d atLowerCornerOf(class_2382 toCopy) {
/* 123 */     return new Vector3d(toCopy.method_10263(), toCopy.method_10264(), toCopy.method_10260());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_,_->param5", mutates = "param5")
/*     */   public static Vector3d atLowerCornerWithOffset(class_2382 toCopy, double offsetX, double offsetY, double offsetZ, Vector3d dest) {
/* 138 */     return dest.set(toCopy.method_10263() + offsetX, toCopy.method_10264() + offsetY, toCopy.method_10260() + offsetZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_,_->new", pure = true)
/*     */   public static Vector3d atLowerCornerWithOffset(class_2382 toCopy, double offsetX, double offsetY, double offsetZ) {
/* 152 */     return new Vector3d(toCopy.method_10263() + offsetX, toCopy.method_10264() + offsetY, toCopy.method_10260() + offsetZ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   public static Vector3d atCenterOf(class_2382 toCopy, Vector3d dest) {
/* 164 */     return dest.set(toCopy.method_10263() + 0.5D, toCopy.method_10264() + 0.5D, toCopy.method_10260() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static Vector3d atCenterOf(class_2382 toCopy) {
/* 175 */     return new Vector3d(toCopy.method_10263() + 0.5D, toCopy.method_10264() + 0.5D, toCopy.method_10260() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   public static Vector3d atBottomCenterOf(class_2382 toCopy, Vector3d dest) {
/* 187 */     return dest.set(toCopy.method_10263() + 0.5D, toCopy.method_10264(), toCopy.method_10260() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static Vector3d atBottomCenterOf(class_2382 toCopy) {
/* 198 */     return new Vector3d(toCopy.method_10263() + 0.5D, toCopy.method_10264(), toCopy.method_10260() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_,_->param3", mutates = "param3")
/*     */   public static Vector3d upFromBottomCenterOf(class_2382 toCopy, double verticalOffset, Vector3d dest) {
/* 210 */     return dest.set(toCopy.method_10263() + 0.5D, toCopy.method_10264() + verticalOffset, toCopy.method_10260() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->new", pure = true)
/*     */   public static Vector3d upFromBottomCenterOf(class_2382 toCopy, double verticalOffset) {
/* 221 */     return new Vector3d(toCopy.method_10263() + 0.5D, toCopy.method_10264() + verticalOffset, toCopy.method_10260() + 0.5D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static class_243 toMojang(Vector3dc vec3d) {
/* 232 */     return new class_243(vec3d.x(), vec3d.y(), vec3d.z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static class_241 toMojang(Vector2fc vec2f) {
/* 243 */     return new class_241(vec2f.x(), vec2f.y());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static class_2382 toMojang(Vector3ic vec3i) {
/* 254 */     return new class_2382(vec3i.x(), vec3i.y(), vec3i.z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_->new", pure = true)
/*     */   public static Vector3d getAABBCenter(class_238 aabb) {
/* 265 */     return new Vector3d((aabb.field_1323 + aabb.field_1320) / 2.0D, (aabb.field_1322 + aabb.field_1325) / 2.0D, (aabb.field_1321 + aabb.field_1324) / 2.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Contract(value = "_,_->param2", mutates = "param2")
/*     */   public static Vector3d getAABBCenter(class_238 aabb, Vector3d dest) {
/* 280 */     return dest.set((aabb.field_1323 + aabb.field_1320) / 2.0D, (aabb.field_1322 + aabb.field_1325) / 2.0D, (aabb.field_1321 + aabb.field_1324) / 2.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\Agg\Downloads\EternallyBoundPlus+1.21.1.jar!\META-INF\jars\sable-companion-fabric-1.21.1-1.6.0.jar!\dev\ryanhcode\sable\companion\math\JOMLConversion.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */